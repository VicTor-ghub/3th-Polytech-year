  function Etatdot=modeleRobot(Etat,commande,rob)
    
    rob.tau=0.5;
    %R�cup�ration des vitesses et vitesse angulaire
    xdot=(rob.R)/2*(Etat(4,1)+Etat(5,1))*cos(Etat(3,1));
    ydot=(rob.R)/2*(Etat(4,1)+Etat(5,1))*sin(Etat(3,1));
    tetadot=((rob.R)/(2*rob.L))*(Etat(4,1)- Etat(5,1));
    %R�cup�ration des commandes des roues 
    wddot=(-1/(rob.tau))*(Etat(4,1))+(1/rob.tau)*commande(1);
    wgdot=(-1/(rob.tau))*(Etat(5,1))+(1/rob.tau)*commande(2);
    %R�cup�ration de l'�tat du robot
    Etatdot=[xdot;ydot;tetadot;wddot;wgdot];

end 