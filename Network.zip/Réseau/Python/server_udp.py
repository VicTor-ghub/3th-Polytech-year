from socket import *

# Création de l’objet socket
s= socket(AF_INET, SOCK_DGRAM)

print('serveur démarré')
#mise en écoute du serveur
s.bind(('162.38.40.31',8888))

print ('bind en route, en attente de réception')

data, addr=s.recvfrom(1024) #ici reçoit A
data=data.decode('utf-8')
print("recu :" ,data)

s.sendto(bytes('B','utf-8'),addr)

s.close()
