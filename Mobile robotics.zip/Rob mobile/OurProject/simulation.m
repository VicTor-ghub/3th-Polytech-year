function simulation

environnement_init;
rob=robot_init;

%Initialisation de l'Etat et de la cible
Etat=[0;0;0;0;0];                       %Etat=[x;y;teta;wd;wg]
cible=[rob.fin(1);rob.fin(2);pi/2];     %cible=[xd; yd; tetad]
%Init commande
wdbarre=1;
wgbarre=1;
commande=[wdbarre wgbarre];
%Init temps
t=0;
dt=0.1;

%Initialisation des capteurs
% %d1=3;
% d2=3;
% d3=3;
% dmax=3;
% wmax=10;

% capteurs= [d1 theta1;d2 theta2; d3 theta3];

while  t<12000
   
    %Int�gration des vitesses pour r�cup�ration de la position avec T=t+tau
    [T,X]= ode45(@(t,Etat)modelerobot(Etat,commande,rob),[0 dt],Etat);
    Etat=X(length(X),:)';
    %Matrice de passage 
    M=[cos(Etat(3,1)) -sin(Etat(3,1)) Etat(1,1);sin(Etat(3,1)) cos(Etat(3,1)) Etat(2,1); 0 0 1];
    % A et B sont les coordonn�es du point R 
    aprime = M*[rob.roueG(1);rob.roueG(2);1];   % Nouvelle coordon�es du point roueG
    bprime = M*[rob.roueD(1);rob.roueD(2);1];   % Nouvelle coordon�es du point roueD
    cprime = M*[rob.top(1);rob.top(2);1];       % Nouvelle coordon�es du point top
    
    sommetsprime=[[aprime(1) aprime(2)]; [bprime(1) bprime(2)] ;[cprime(1) cprime(2)]]; 
    
    set(rob.ptr,'vertices',sommetsprime)
    drawnow
    t=t+dt;
    
end
end

