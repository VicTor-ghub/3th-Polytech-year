using Plots
using LinearAlgebra

# Structure géométrique 

global l0=0.2;
global l1=0.4;
global l2=0.3;
global R1= [l0 , l1, l2];
# global theta1=0;
# global theta2=0;
global xr;
global yr;

# Modèle Géométrique Directe (MGD)

function MGD(theta1,theta2)
    xr = l1 * cos(theta1) + l2 * cos(theta1 + theta2);
    yr = l1 * sin(theta1) + l2 * sin(theta1 + theta2)+l0;
    return [xr,yr]
end

function MGD_print()
    cpt = 1;
    X = zeros(2,9999);
    for theta1 in 0.0:0.1:pi
        for theta2 in -pi/2:0.1:pi/2
            X[:,cpt]=MGD(theta1,theta2);
            cpt = cpt + 1;            
        end
    end
    figure = plot(X[1,:],X[2,:], title="Région accessible",xlabel="axe x", ylabel="axe y";seriestype=:scatter)
    display(figure);
end


# Modèle Géométrique Inverse (MGI)

function MGI(xr , yr)
    yr= yr -l0;

    theta2_high= -acos((xr^2+yr^2 -(l1^2+l2^2))/(2*l1*l2));
    theta2_low= acos((xr^2+yr^2 -(l1^2+l2^2))/(2*l1*l2));

    cos_low= (xr*(l1 +l2*cos(theta2_low))+yr*l2*sin(theta2_low))/(xr^2 +yr^2);
    sin_low= (yr*(l1 +l2*cos(theta2_low))-xr*l2*sin(theta2_low))/(xr^2 +yr^2);
    theta1_low=atan(sin_low,cos_low);

    cos_high= (xr*(l1 +l2*cos(theta2_high))+yr*l2*sin(theta2_high))/(xr^2 +yr^2);
    sin_high= (yr*(l1 +l2*cos(theta2_high))-xr*l2*sin(theta2_high))/(xr^2 +yr^2);
    theta1_high=atan(sin_high,cos_high);
 
    if (0 < theta1_high <pi) && (-pi/2< theta2_high < pi/2)
        return [theta1_high,theta2_high]

    elseif (0< theta1_low <pi) && (-pi/2 <theta2_low <pi/2) 
        return [theta1_low,theta2_low]

    else
        println("MGD non respecté = ERREUR")
    end

end

function MGI_print(xr,yr)
    yr= yr -l0;

    theta2_high= -acos((xr^2+yr^2 -(l1^2+l2^2))/(2*l1*l2));
    theta2_low= acos((xr^2+yr^2 -(l1^2+l2^2))/(2*l1*l2));

    cos_low= (xr*(l1 +l2*cos(theta2_low))+yr*l2*sin(theta2_low))/(xr^2 +yr^2);
    sin_low= (yr*(l1 +l2*cos(theta2_low))-xr*l2*sin(theta2_low))/(xr^2 +yr^2);
    theta1_low=atan(sin_low,cos_low);

    cos_high= (xr*(l1 +l2*cos(theta2_high))+yr*l2*sin(theta2_high))/(xr^2 +yr^2);
    sin_high= (yr*(l1 +l2*cos(theta2_high))-xr*l2*sin(theta2_high))/(xr^2 +yr^2);
    theta1_high=atan(sin_high,cos_high);

    if (0< theta1_low <pi) && (-pi/2 <theta2_low <pi/2)
        #Premier segment
        x0=0;
        y0=l0;
        coude_bas=plot([0 ,x0], [0 ,y0],title="Coude bas",xlabel="axe x", ylabel="axe y",labels="l0",seriestype=:line,linewidth = 3,grid=true,aspect_ratio=:equal,xlim=(-1,1),ylim=(0,1))
        #Deuxième segment (low)
        x1_low=x0+ l1*cos(theta1_low);
        y1_low=y0+ l1*sin(theta1_low);
        plot!(coude_bas,[x0 ,x1_low], [y0 ,y1_low],seriestype=:line,labels="l1",linewidth = 3)

        #Troisième segment (low)
        x2_low=x1_low+ l2*cos(theta2_low+theta1_low)
        y2_low=y1_low+ l2*sin(theta2_low+theta1_low)
        plot!(coude_bas,[x1_low ,x2_low], [y1_low ,y2_low],seriestype=:line,labels="l2",linewidth = 3)
        display(coude_bas)
    end

    if (0 < theta1_high <pi) && (-pi/2< theta2_high < pi/2)
        #Premier segment
        x0=0;
        y0=l0;
        coude_haut=plot([0 ,x0], [0 ,y0],title="Coude haut",xlabel="axe x", ylabel="axe y",labels="l0",seriestype=:line,linewidth = 3,grid=true,aspect_ratio=:equal,xlim=(-1,1),ylim=(0,1))
        #Deuxième segment (high)
        x1_high=x0+ l1*cos(theta1_high);
        y1_high=y0+ l1*sin(theta1_high);
        plot!(coude_haut,[x0 ,x1_high], [y0 ,y1_high],seriestype=:line,labels="l1",linewidth = 3)
        #Troisième segment (high)
        x2_high=x1_high+ l2*cos(theta2_high+theta1_high)
        y2_high=y1_high+ l2*sin(theta2_high+theta1_high)
        plot!(coude_haut,[x1_high ,x2_high], [y1_high ,y2_high],seriestype=:line,labels="l2",linewidth = 3)
        display(coude_haut)
    
    else
        println("MGD non respecté = ERREUR")
    end
end


# Modèle Cinématique Direct (MCD)

function MCD(theta1, theta2)
    Jx1=-l1*sin(theta1)-l2*sin(theta1+theta2)
    Jx2=-l2*sin(theta1+theta2)
    Jy1=l1*cos(theta1)+l2*cos(theta1+theta2)
    Jy2=l2*cos(theta1+theta2)

    #Matrice Jacobienne 

    J=[Jx1 Jx2; Jy1 Jy2];

    return J;
end

function MCD_print( )
    #Affichage des vecteurs vitesses 

    vecteurs= plot(0,0,title="Domaine",xlabel="axe x", ylabel="axe y";seriestype=:line)
    
    for i= 0:pi/2:pi                #theta1
        for j= -pi/2:pi/2:pi/2      #theta2
            for k= -5:1:5           #theta1_dot
                for n= -5:1:5       #theta2_dot
                    X= MGD(i,j)
                    J=MCD(i,j)
                    xr_dot=J[1,1]*k + J[1,2]*n 
                    yr_dot=J[2,1]*k + J[2,2]*n
                    vecteurs=scatter!([X[1]],[X[2]],legend= false)
                    vecteurs=quiver!([X[1]],[X[2]],quiver=([xr_dot/10],[yr_dot/10]));
                end
            end
        end
    end
    display(vecteurs)
end


# Modèle Cinématique Inverse (MCI)

function MCI(xr_dot,yr_dot,theta1, theta2)
    J=MCD(theta1,theta2)
    check=det(J);
    if check<0.01
        J_inv=inv(J)
        #Vitesse carthésienne
        xr_dot=1;
        yr_dot=0;
        #Récupération vitesse angulaire
        theta_dot=[];
        theta_dot[1]=J_inv*xr_dot;
        theta_dot[2]=J_inv*yr_dot;
        return theta_dot
    
    else println("Matrice J non inversible ")
    end    
end

#TEST MGD
# MGD_print()

#TEST MGI
# xr= 0.4;
# yr= 0.6;
# MGI_print(xr,yr);

#TEST MCD
# MCD_print()

#TEST MCI
MCI(1,0,pi/2,pi/2)