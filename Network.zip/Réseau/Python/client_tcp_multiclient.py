from socket import *
from time import sleep
s=socket(AF_INET,SOCK_STREAM)
s.connect(('192.168.7.2',8888))
s.sendall(bytes('mesg','utf-8'))
data=s.recv(1024)
data.decode('utf-8')
s.sendall(bytes('exit','utf-8'))
sleep(1)
s.close()