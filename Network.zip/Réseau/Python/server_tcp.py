from socket import *

s=socket(AF_INET,SOCK_STREAM)

s.setsockopt(SOL_SOCKET,SO_REUSEADDR, 1)
s.bind(('192.168.7.2',8888))
s.listen(5)

#process en attente de connexion du client (s.connect)
connection, address = s.accept()
print ('le client est ', address)

#le serveur lit le buffer (ou attend si le buffer est vide)
data = connection.recv(1024)
data=data.decode('utf-8')
connection.sendall(bytes('coucou\n','utf-8'))

connection.close()
s.close()