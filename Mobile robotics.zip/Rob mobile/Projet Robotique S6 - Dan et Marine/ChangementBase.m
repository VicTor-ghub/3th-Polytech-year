function ChangementBase
T = [cos(rob.theta) -sin(rob.theta) rob.X; sin(rob.theta) cos(rob.theta) rob.Y; 0 0 1];

if(abs(det(T)) > 0.00001)
    matrice = [rob.X; rob.Y; 1];
    inter = T/matrice; %Diviser reviens � faire l'inverse et Matlab calcule plus vite comme �a
    rob.X = inter(1,:); %Coordonn�es de X et Y dans le rep�re du robot
    rob.Y = inter(2,:);
end
end