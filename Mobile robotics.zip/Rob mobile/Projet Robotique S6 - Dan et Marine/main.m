%%Initialisation de l'environnement
function main
clc;
close all; clear all; %%On nettoie les r�sidus
%global rob.rob.commande;

%Initialisation des figures
figure(1)
clf; hold on;
set(figure(1),'WindowStyle','modal')
%Placer la figure
set(1, 'position', [200 200 400 400])
axis([-20 20 -20 20]);

%Initialisation du syst�me (robot)
x = [0 0 0 0 0];
rob.R = 0.05;
rob.L = 0.8;
rob.X = x(1); rob.Y = x(2);
rob.theta = x(3);
rob.H = 0.8;
u(1) = 0;
u(2) = 0;
rob.wd = u(1);
rob.wg = u(2);
C = [(rob.R)/2 (rob.R)/2; (rob.R)/(rob.L) -(rob.R)/(rob.L)];
xd = 10; yd = 10; thetad = 0;
fin = 0;

%Initialisation de l'environnement d'ex�cution
Tmax = 100;
dt = 0.1;

%Programme (hors initialisation)
count = 0;
rob.commande = [0;0];

Xr = [rob.X + (rob.L/2)*sin(rob.theta); rob.X - (rob.L/2)*sin(rob.theta); rob.X + rob.H*cos(rob.theta)];
Yr = [rob.Y - (rob.L/2)*cos(rob.theta); rob.Y + (rob.L/2)*cos(rob.theta); rob.Y + rob.H*sin(rob.theta)];
rob.ptr = patch(Xr, Yr, [1 0 0]);

capteur1.ptr = line([2 0], [0 0]); 
capteur2.ptr = line([2 0], [0 0]);
capteur3.ptr = line([2 0], [0 0]);

%////////////////////////////////////////////////////////////////////////////////////////////////%

%G�n�ration d'obstacles
nb_obstacle = 4;

X(1).obs = [15 15];
Y(1).obs = [-15 15];
obstacle(1).ptr = line(X(1).obs, Y(1).obs, 'linewidth', 3);
set(obstacle(1).ptr, 'xdata', X(1).obs, 'ydata', Y(1).obs);

X(2).obs = [15 -15];
Y(2).obs = [15 15];
obstacle(2).ptr = line(X(2).obs, Y(2).obs, 'linewidth', 3);
set(obstacle(2).ptr, 'xdata', X(2).obs, 'ydata', Y(2).obs);

X(3).obs = [-15 -15];
Y(3).obs = [15 -15];
obstacle(3).ptr = line(X(3).obs, Y(3).obs, 'linewidth', 3);
set(obstacle(3).ptr, 'xdata', X(3).obs, 'ydata', Y(3).obs);

X(4).obs = [-15 15];
Y(4).obs = [-15 -15];
obstacle(4).ptr = line(X(4).obs, Y(4).obs, 'linewidth', 3);
set(obstacle(4).ptr, 'xdata', X(4).obs, 'ydata', Y(4).obs);

angle = 24;

%//////////////////////////////////////////////////////////////////////////////////////////////////%
if(fin==0)
for t = 0:dt:Tmax
    %Mise � jour de l'�tat du robot
    rob.X = x(1); rob.Y = x(2); rob.theta = x(3); rob.wd = u(1); rob.wg = u(2);
    Xcapteur1 = [rob.X rob.X + 3*rob.H*cos(rob.theta)];
    Ycapteur1 = [rob.Y rob.Y + 3*rob.H*sin(rob.theta)];
    Xcapteur2 = [rob.X rob.X + 3*rob.H*cos(rob.theta+angle)];
    Ycapteur2 = [rob.Y rob.Y + 3*rob.H*sin(rob.theta+angle)];
    Xcapteur3 = [rob.X rob.X + 3*rob.H*cos(rob.theta-angle)];
    Ycapteur3 = [rob.Y rob.Y + 3*rob.H*sin(rob.theta-angle)];
    
    %Mise � jour du desin
    set(rob.ptr, 'xdata', Xr, 'ydata', Yr);
    set(capteur1.ptr, 'xdata', Xcapteur1, 'ydata', Ycapteur1);
    set(capteur2.ptr, 'xdata', Xcapteur2, 'ydata', Ycapteur2);
    set(capteur3.ptr, 'xdata', Xcapteur3, 'ydata', Ycapteur3);
    Xr = [rob.X + (rob.L/2)*sin(rob.theta); rob.X - (rob.L/2)*sin(rob.theta); rob.X + rob.H*cos(rob.theta)];
    Yr = [rob.Y - (rob.L/2)*cos(rob.theta); rob.Y + (rob.L/2)*cos(rob.theta); rob.Y + rob.H*sin(rob.theta)];
    drawnow;
    %//////////////////////////////////////////////////////////////////////////////////////////////////////////////%
    
    %Calcul de la rob.commande
    %rob.commande(1) = rob.commande(1)+1;
    %rob.commande(2) = rob.commande(2)+1;
        
%     u(1) = ((rob.R)/2)*(rob.commande(1) + rob.commande(2));
%     u(2) = ((rob.R)/(2*rob.L))*(rob.commande(1) - rob.commande(2));
    %Simulation du robot
%     [t45, x45] = ode45(@(t, x)Modele(t,u,x,rob)', [0 dt], x);
%     L45 = length(t45);
%     x = x45(L45, :);
    
    count = count+1;
    %Trac� des trajectoire
    x_STOCK(:, count) = x;
    
    plot(x_STOCK(1,:), x_STOCK(2,:), 'g')
    pause(0.01);
    donnetout = 0;
    %//////////////////////////////////////////////////////////////////////////////////////////////////////%
    %D�tection d'obstacle
    for i=1:nb_obstacle;
        P1 = [Xcapteur1(2);Ycapteur1(2)];
        R1 = [Xcapteur1(1);Ycapteur1(1)];
        P2 = [Xcapteur2(2);Ycapteur2(2)];
        R2 = [Xcapteur2(1);Ycapteur2(1)];
        P3 = [Xcapteur3(2);Ycapteur3(2)];
        R3 = [Xcapteur3(1);Ycapteur3(1)];
    
        A = [X(i).obs(2); Y(i).obs(2)];
        B = [X(i).obs(1); Y(i).obs(1)];
        M1 = [P1-R1 A-B];
        M2 = [P2-R2 A-B];
        M3 = [P3-R3 A-B];
        %donnetout = eviteObstacle(Xcapteur1, Ycapteur1, Xcapteur2, Ycapteur2, Xcapteur3, Ycapteur3, A, B);
       
       E1 = abs(det(M1));
       E2 = abs(det(M2));
       E3 = abs(det(M3));
    
    if((E1 > 0.00001)&&(E2 > 0.00001)&&(E3 > 0.00001))
        st1 = (M1)\(A-R1);
        s1 = st1(1);
        t1 = st1(2);
        st2 = (M2)\(A-R2);
        s2 = st2(1);
        t2 = st2(2);
        st3 = (M3)\(A-R3);
        s3 = st3(1);
        t3 = st3(2);
    else
        s1 = 10;
        t1 = 10;
    end
    xrob = rob.X; yrob = rob.Y; thetarob = rob.theta; wdrob = rob.wd; wgrob = rob.wg;
    Etat = [xrob;yrob;thetarob;wdrob;wgrob];
    Cible = [xd;yd;thetad];
    Capteurs = zeros(3,2);
    
        Capteurs(1,1) = 2*s1; Capteurs(1,2) = -pi/6;
        Capteurs(2,1) = 2*s1; Capteurs(1,2) = 0;
        Capteurs(3,1) = 2*s1; Capteurs(1,2) = pi/6;
    
%     if((s1 <= 1)&&(s1 >= 0)&&(t1<= 1)&&(t1>=0))
%         donnetout = 1;
% 
%     elseif((abs(det(M2)) > 0.0001))
%         st2 = (M2)\(A-R2);
%         s2 = st2(1);
%         t2 = st2(2);
%         
%         if((s2 <= 1)&&(s2 >= 0)&&(t2<=1)&&(t2>=0))
%             donnetout = 2;
%             
%         elseif(abs(det(M3)) > 0.0001) %v�rifier avec un point d'arr�t les valeurs de s3 et t3
%             st3 = (M3)\(A-R3);
%             s3 = st3(1);
%             t3 = st3(2);
%             
%             if((s3 <= 1)&&(s3 >= 0)&&(t3<= 1)&&(t3>=0))
%                 donnetout = 3;
%             end
%         end
%     end
%        
%        switch(donnetout)
%            case 1
% %                rob.commande(1) = 10;
% %                rob.commande(2) = -2.5;
%                  v(1) = 3;
%                  v(2) = 0.01;
%            case 2
% %                rob.commande(1) = 10;
% %                rob.commande(2) = -2.5;
%                  v(1) = 3;
%                  v(2) = 0.01;
%            case 3
% %                rob.commande(1) = -2.5;
% %                rob.commande(2) = 10;
%                  v(1) = 3;
%                  v(2) = -0.01;
%            otherwise
% %                rob.commande(1) = 10;
% %                rob.commande(2) = 10;
%                  v(1) = 3;
%                  v(2) = 0;
%        end
%        u = C\(v');
%     end
if((u(1)~=0)&&(u(2)~=0))
    [t45, x45] = ode45(@(t, x)Modele(t,u,x,rob)', [0 dt], x);
    L45 = length(t45);
    x = x45(L45, :);
end
%     
%     if(((abs((xd-rob.X))<=2)||((abs(yd-rob.Y))<=2))&&(fin==0))
%         rob.theta = rob.theta - atan(abs(yd-rob.Y)/abs(xd-rob.X));
%         v(1) = 3;
%         v(2) = 0;
%         u = C\(v');
%         fin = 1;
%         if((abs((xd-rob.X))<=0.1)||((abs(yd-rob.Y))<=0.1))
%             v(1) = 0;
%             v(2) = 0;
%             u = C\(v');
%             break;
%         end
%     end
       u=controle(Etat,Cible,Capteurs);
    end
end
end