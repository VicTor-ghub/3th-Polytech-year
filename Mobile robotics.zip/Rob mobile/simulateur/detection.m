function capteurs = detection(Etat, obstacles)

dmax = 3;
capteurs = [dmax -pi/6 ;
            dmax    0  ;
            dmax  pi/6 ];

for c = 1:3
    
    A = [Etat(1) ; Etat(2)];
    B = [Etat(1)+dmax*cos(Etat(3) + capteurs(c,2)) ;...
         Etat(2)+dmax*sin(Etat(3) + capteurs(c,2))];
    
    d = dmax;
    for o=1:size(obstacles,2)
        
        P = [obstacles(1,o);obstacles(2,o)];
        Q = [obstacles(3,o);obstacles(4,o)];
        
        H = [(B-A) (P-Q)];
        
        if(abs(det(H))>0.0001)
            st = H\(P-A);
            if(st(1) > 0 && st(1) < 1 && st(2) > 0 && st(2) < 1)
                dx = B(1)-A(1);
                dy = B(2)-A(2);
                distance = st(1) * sqrt(dx^2 + dy^2);
                if(distance <d)
                    d = distance;
                end
            end
        end
    end
    
    capteurs(c,1) = d;
end

%% DEBUG
R = Etat(1:2);
for c=1:3
    if ( (capteurs(c,1) < dmax) && (capteurs(c,1) > 0))
        %plot( R(1)+capteurs(c,1)*cos(Etat(3)+capteurs(c,2)) , R(2)+capteurs(c,1)*sin(Etat(3)+capteurs(c,2)),'r.');
    end
end

end