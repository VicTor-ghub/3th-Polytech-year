from socket import *
from threading import Thread
import sys
s=socket(AF_INET,SOCK_STREAM)
s.setsockopt(SOL_SOCKET,SO_REUSEADDR, 1)
try :
s.bind(('192.168.7.2',8888))
s.listen(5)
except ValueError as message :
print(message)
sys.exit(1)
#process en attente de connexion
#demarre un thread independant a chaque communication etablie
def dispatcher():
 while 1:
 connection, address = s.accept()
 print('Server connected by', address)
 tcp_client=Thread(target=handleClient, args=(connection,))
 tcp_client.start()
#thread pour chaque connexion qui arrive (multitache)
def handleClient(connection):
 data=''
 while data!='exit':
 data = connection.recv(1024)
 data=data.decode('utf-8')
 if not data: break
 connection.sendall(bytes('recu','utf-8'))
 connection.close()
#debut prog principal
dispatcher()
