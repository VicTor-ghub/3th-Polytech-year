function obstacles=map(num_map)

obstacles = [];
switch num_map
    case 1
        obstacles(:,1) = [0;10;20;10];
        obstacles(:,2) = [0;4;5;10];
        obstacles(:,3) = [20;4;15;10];
    case 2
        obstacles(:,1) = [5;10;15;10];
        obstacles(:,2) = [5;10;5;16];
        obstacles(:,3) = [5;10;4;11];
        obstacles(:,4) = [15;10;15;16];
        obstacles(:,5) = [15;10;16;11];
        obstacles(:,6) = [8.75;11.5;8.75;18];
        obstacles(:,7) = [8.75;18;11.25;18];
        obstacles(:,8) = [11.25;11.5;11.25;18];
end


end