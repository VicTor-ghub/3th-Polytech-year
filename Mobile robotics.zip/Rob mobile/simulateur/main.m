%% Initialisation de l'environnement %%
clearvars -except obstacles
close all
clear controle;
if exist('obstacles','var')
    existing_map = questdlg('Voulez-vous utiliser le terrain pr�c�dent ?','Terrain enregistr�e','Yes','No','No');
else
    clear all;
    existing_map = 'No';
end
figure(1)
clf
hold on
axis equal
win_size = [-4 24 -4 24];   % Dimensions du terrain de simulation
axis(win_size);


%% Infos mission %%
Tmax = 300;                 % Temps max de simulation
Nmin = 0.05;                % Distance � l'arriv�e minimum
Wmax = 10;                  % Vitesse de rotation max des roues
theta_A = -pi/2;            % Orientation souhait� du robot � l'arriv�
robot_x2 = 0;               % 0 => 1 robot / 1 => 2 robots
detectionAdversaire = 1;    % 1 => activation de la d�tection d'adversaire


%% User interface
givenbyuser = 0;
if strcmp(existing_map,'No')
    clearvars obstacles
    map_select = questdlg('Load map ?','Map selection','1','2','Create','Create');
    switch map_select
        case '1'
            obstacles = map(1);
        case '2'
            obstacles = map(2);
        case 'Create'
            nb_obs = inputdlg({'Nombre d''obstacles (1~5):'},'Choix du nombre d''obstacles', [1 51]);
            nb_obs = str2double(nb_obs);
            if isempty(nb_obs) || isnan(nb_obs) || nb_obs<1 || nb_obs>5
                title(sprintf('Input must be numeric and between 1 to 5'));
                error('Input must be numeric and between 1 to 5.');
            end
            givenbyuser = 1;
            obstacles = zeros(4,nb_obs);
    end
end

%% Obstacles
for i=1:size(obstacles,2)
    if givenbyuser
        % Placement
        obs_A = ginput(1);
        obs_B = ginput(1);
        
        % Stockage
        obstacles(:,i) = [obs_A(1);obs_A(2);obs_B(1);obs_B(2)];
    end
    
    % Affichage
    line([obstacles(1,i) obstacles(3,i)], ...
        [obstacles(2,i) obstacles(4,i)],'color','b');
end


%% Point d�part & arriv�e
placement = questdlg('Placement des points de d�part et arriv�e','','Manuel','Auto','Auto');

if strcmp(placement,'Manuel')
    title(sprintf('Cliquez pour placer le point de d�part'));
    pt_D = ginput(1);
    plot(pt_D(1),pt_D(2),'x');
    if robot_x2
        title(sprintf('Cliquez pour placer le 2e point de d�part'));
        pt_D2 = ginput(1);
        plot(pt_D2(1),pt_D2(2),'x');
    end
    title(sprintf('Cliquez pour placer le point d''arriv�e'));
    pt_A = ginput(1);
    plot(pt_A(1),pt_A(2),'x');
else
    pt_D = [5,0];
    pt_D2 = [15,0];
    pt_A = [10,15];
    plot(pt_A(1),pt_A(2),'x');
end

%% Robot

% Etat initial du robot
x = pt_D(1);                % position x
y = pt_D(2);                % position y
theta = -pi/2;              % angle

% Dimensions
rob.R = 0.05;               % Rayon des roues
rob.L = 0.4;                % 1/2 de l'entreaxe
rob.Longueur = 0.8;         % Longueur du robot

% Forme
a_r=[0 -rob.L];
b_r=[0 rob.L];
c_r=[rob.Longueur 0];

% Affichage
a=a_r+[x y];
b=b_r+[x y];
c=c_r+[x y];
fig_pts = [a; b; c];
fig_faces = [1 2 3];
fig = patch('vertices',fig_pts,'faces',fig_faces,'facecolor','g');
if robot_x2
    fig_pts2 = [a; b; c];
    fig2 = patch('vertices',fig_pts2,'faces',fig_faces,'facecolor','b');
    Etat2 = [pt_D2(1);pt_D2(2); theta; 0; 0];
    commande2 = [0;0];
end


%% SETUP %%

btn_stop = uicontrol('Style','togglebutton','Units', 'Normalized','String','STOP','Value',0);

Etat = [x; y; theta; 0; 0];
Cible = [pt_A(1); pt_A(2); theta_A];
%Capteurs = [dist1 theta1; dist2 theta2; dist3 theta3];

% Commande initiale
commande = [0;0];   %[Wd;Wg]


%% Rayons des capteurs
rayons = [];
for i=1:3
    ptr = line([0 0],[0 0], 'color', 'r');
    rayons = [rayons, ptr];
end

% Temps
t = 0;
dt = 0.1;


%% MAIN LOOP %%
fini = 0;
while ( t<Tmax )
    Etat_old = Etat;
    % Robot control with mouse
%     mouse = get(0, 'PointerLocation');
%     Cible(1) = mouse(1)*win_size(2)/1366;
%     Cible(2) = mouse(2)*win_size(4)/768;
    
    % Matrice de translation & rotation
    M = [cos(Etat(3)) -sin(Etat(3))  Etat(1); ...
        sin(Etat(3))  cos(Etat(3))  Etat(2); ...
        0             0          1    ];
    
    % Nouveaux points du triangle
    fig_pts = M * [ a_r(1)  b_r(1)  c_r(1) ; ...
        a_r(2)  b_r(2)  c_r(2) ; ...
        1       1       1    ];
     
    set(fig,'vertices', transpose(fig_pts(1:2,:)));
    
    % Mesures capteurs
    Capteurs = detection(Etat, obstacles);
    
    if robot_x2
        M2 = [cos(Etat2(3)) -sin(Etat2(3))  Etat2(1); ...
            sin(Etat2(3))  cos(Etat2(3))  Etat2(2); ...
            0             0          1    ];
        fig_pts2 = M2 * [ a_r(1)  b_r(1)  c_r(1) ; ...
            a_r(2)  b_r(2)  c_r(2) ; ...
            1       1       1    ];
        set(fig2,'vertices', transpose(fig_pts2(1:2,:)));
        
        Capteurs2 = detection(Etat2, obstacles);
        
        if detectionAdversaire
            if norm(Etat2(1:2)-Cible(1:2))>3
                Capteurs = detectionRob(Etat, Etat2, Capteurs);
            end
            if norm(Etat(1:2)-Cible(1:2))>3
                Capteurs2 = detectionRob(Etat2, Etat, Capteurs2);
            end
        end
        
        commande2 = controle(Etat2,Cible,Capteurs2);
        
        if (commande2(1)>Wmax+0.001 || commande2(2)>Wmax+0.001)
            msgbox('vitesse trop �lev�e');
            disp(commande2(1:2));
            t = Tmax;
        end
        
        [t45, x45] = ode45(@(t, Etat2) modele(Etat2,commande2,rob), [0 dt], Etat2);
        L45 = length(t45);
        Etat2 = transpose(x45(L45,:));
    end
    
    % Affichage des rayons des capteurs
    for i=1:3
        P = [ Etat(1)+Capteurs(i,1)*cos(Etat(3)+Capteurs(i,2)) ; ...
            Etat(2)+Capteurs(i,1)*sin(Etat(3)+Capteurs(i,2)) ];
        set(rayons(i), 'XData',[Etat(1) P(1)], 'YData', [Etat(2) P(2)]);
    end
    
    % test obs mobiles
%      obstacles(2,nb_obs) = obstacles(2,nb_obs)+0.01;
%      obstacles(4,nb_obs) = obstacles(4,nb_obs)+0.01;
%      set(mvline, 'Ydata', [obstacles(2,nb_obs) obstacles(4,nb_obs)]);
    
    % Trace la trajectoire
    %plot(Etat(1),Etat(2),'g.');
    %plot(Etat2(1),Etat2(2),'b.');
    
    drawnow;
    
    % Acquisition de la prochaine commande
    commande = controle(Etat,Cible,Capteurs);
    xlabel(sprintf('Wd: %.2f \n Wg: %.2f',commande(1),commande(2)));
    
    % Contr�le de la vitesse
    if (commande(1)>Wmax+0.0001 || commande(2)>Wmax+0.0001)
        msgbox('vitesse trop �lev�e');
        disp(commande(1:2));
        t = Tmax;
    end
    
    % Simulation de l'�tat suivant
    [t45, x45] = ode45(@(t, Etat) modele(Etat,commande,rob), [0 dt], Etat);
    L45 = length(t45);
    Etat = transpose(x45(L45,:));

    if collisionDetection(Etat,obstacles,Etat_old)
        title(sprintf('CRASH !'));
        answer = questdlg('Collision d�tect� : continuer quand m�me ?','Crash alert','Oui','Non','Non');
        if strcmp(answer,'Non')
            error('Simu stopp�e suite � une collision');
        end
    end
    
    % Temps ++
    t = t + dt;
    
    if(get(btn_stop, 'Value') == 1)
        set(btn_stop, 'String','STOPPED'); %mettre un point d'arr�t ici
    end
    
    e = Cible(3) - Etat(3);
    e = angle(cos(e) + 1i * sin(e)) / pi;
    
    if (~fini)
        title(sprintf('t=%.1f',t));
        if (norm(Cible(1:2)-Etat(1:2))<Nmin && abs(e)<0.03)
            fini = 1;
            title(sprintf('Bien arriv�, temps mis: %.1f',t));
        end
    end
end
