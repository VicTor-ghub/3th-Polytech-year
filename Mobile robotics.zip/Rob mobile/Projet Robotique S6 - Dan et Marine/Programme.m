function Programme
Etat = [x;y;theta;wd;wg];
Cible = [xd;yd;thetad];
R = 0.05;
L = 0.4;
Longueur = 0.8;
dt = 0.1;
commande = [0;0];
dmax = 3;
wmax = 10;

while()
    [Etat,Capteurs]=simulateur(Etat,commande);
    commande=controle(Etat,Cible,Capteurs);
    
end


end