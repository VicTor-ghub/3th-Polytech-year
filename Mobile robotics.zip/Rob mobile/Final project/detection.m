   function X=detection(obs, nbro, Lgauche, Lcentre, Ldroite, R)
      
   S1=ones(13,3);
   S2=ones(13,3);
   S3=ones(13,3);
      
   for i=1 : 1 : nbro
          %Coordonees de l'obstacle
          O1= [ obs(i, 1) obs(i, 2)];  
          O2= [ obs(i, 3) obs(i, 4)];

          %Matrice de l'�quation param�trique  
                   % x=R+s(PLaser-R)
                   % y=O1+G(O2-O1)

           M1=[ (Lgauche'-R') (O1'-O2')];
           M2=[ (Lcentre'-R') (O1'-O2')];
           M3=[ (Ldroite'-R') (O1'-O2')];

           OR= O1-R;

           d1=det(M1);
           d2=det(M2);
           d3=det(M3);

           if( abs(d1)>0.0001 ) %Detection d'intersection pour le laser Droite
                    SG1 =  M1\OR'; %Distance capteur obstacle matrice [S gamma]
                    if(SG1(1)<1 && SG1(1)>0 && SG1(2)<1 && SG1(2)>0)   %condition d'intersection obs-laser
                    S1(i,1)=abs(SG1(1));
                    S1(i,2)=abs(SG1(2));
                    end
           end
           if( abs(d2)>0.0001 )%detection d'intersection pour le laser Centre
                    SG2 =  M2\OR';
                    if(SG2(1)<1 && SG2(1)>0 && SG2(2)<1 && SG2(2)>0)
                    S2(i,1)=abs(SG2(1));
                    S2(i,2)=abs(SG2(2));
                    end
           end
           if( abs(d3)>0.0001 )%detection d'intersection pour le laser Gauche
                    SG3 = M3\OR';
                    if(SG3(1)<1 && SG3(1)>0 && SG3(2)<1 && SG3(2)>0)
                     S3(i,1)=abs(SG3(1));
                     S3(i,2)=abs(SG3(2));
                    end            
           end
   end
      
  
%CREATION DE LA MATRICE D'INTERSECTION
%VALEURS de S et Gamma minimales pour chaque capteur 

   X1=min(S1)'; %capteur droite : valeur min d'intersection avec tous les obstacles
   X(1,1)=X1(1,1);  %Smin
   X(1,2)=X1(2,1);  %Gammamin
   
   X2=min(S2)' ; %capteur centre : valeur min d'intersection avec tous les obstacles
   X(2,1)=X2(1,1);  %Smin
   X(2,2)=X2(2,1);  %Gammamin
   
   X3=min(S3)' ;% capteur gauche : valeur min d'intersection avec tous les obstacles
   X(3,1)=X3(1,1);  %Smin
   X(3,2)=X3(2,1);  %Gammamin
   
   % X est la matrice qui renvoie les distances des intersections minimales
   % S et Gamma pour chacun des lasers.
   
end 