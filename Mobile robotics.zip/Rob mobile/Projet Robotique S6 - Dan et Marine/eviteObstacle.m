function donnetout = eviteObstacle(Xcapteur1, Ycapteur1, Xcapteur2, Ycapteur2, Xcapteur3, Ycapteur3, A, B)
        P1 = [Xcapteur1(2);Ycapteur1(2)];
        R1 = [Xcapteur1(1);Ycapteur1(1)];
        P2 = [Xcapteur2(2);Ycapteur2(2)];
        R2 = [Xcapteur2(1);Ycapteur2(1)];
        P3 = [Xcapteur3(2);Ycapteur3(2)];
        R3 = [Xcapteur3(1);Ycapteur3(1)];
        M1 = [P1-R1 A-B];
        M2 = [P2-R2 A-B];
        M3 = [P3-R3 A-B];
        
         E = abs(det(M1));
    
    if(E > 0.0001)
        st1 = (M1)\(A-R1);
        s1 = st1(1);
        t1 = st1(2);
    else
        s1 = 10;
        t1 = 10;
    end
    
    if((s1 <= 1)&&(s1 >= 0)&&(t1<= 1)&&(t1>=0))
        donnetout = 1;

    elseif((abs(det(M2)) > 0.0001))
        st2 = (M2)\(A-R2);
        s2 = st2(1);
        t2 = st2(2);
        
        if((s2 <= 1)&&(s2 >= 0)&&(t2<=1)&&(t2>=0))
            donnetout = 2;
            
        elseif(abs(det(M3)) > 0.0001) %v�rifier avec un point d'arr�t les valeurs de s3 et t3
            st3 = (M3)\(A-R3);
            s3 = st3(1);
            t3 = st3(2);
            
            if((s3 <= 1)&&(s3 >= 0)&&(t3<= 1)&&(t3>=0))
                donnetout = 3;
            else
                donnetout = 0;
            end
        end
    end
        
        
end