function environnement_init

%Initialisation de l'environnement
figure(1)
clf
hold on
%Intialisation du rep�re carth�sien
axis([-10 10 -10 10]) %d�finition des axes
axis equal
% Cr�ation des obstacles
line([5 -5],[5 2],'color', 'b')
line([-8 2],[-5 5],'color', 'b')
line([-3 5],[5 -5],'color', 'b')
line([4 -2],[2 -2],'color', 'b')
line([-5 3],[-7 0],'color', 'b')

end