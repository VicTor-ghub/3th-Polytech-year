function Rob=robot_init

%Initialisation du robot
Rob.nom='VM';
Rob.L=1; %Entreaxe
Rob.R=0.05; %Rayon des roues
Rob.longueur= 0.8; %longueur du robot
[Rob.X,Rob.Y]= ginput(1)
Rob.top=[Rob.X+Rob.longueur Rob.Y];
Rob.roueG=[Rob.X Rob.Y+Rob.L/2];
Rob.roueD=[Rob.X Rob.Y-Rob.L/2];
%Cr�ation du robot
sommets=[Rob.roueG;Rob.roueD;Rob.top]
faces=[1 2 3];
Rob.ptr=patch('vertices', sommets, 'faces', faces, 'facecolor', 'm');
%Cr�ation de la cible
Rob.fin=ginput(1)
plot(Rob.fin(1),Rob.fin(2),'*')