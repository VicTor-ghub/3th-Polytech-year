function xdot = Modele(t,u,x,rob)
% xdot(1) = u(1)*cos(x(3));
% xdot(2) = u(1)*sin(x(3));
% xdot(3) = u(2);
 
    tau = 0.1;
    xdot(1) = ((x(4)+x(5))*rob.R*cos(x(3)))/2;
    xdot(2) = ((x(4)+x(5))*rob.R*sin(x(3)))/2;
    xdot(3) = ((x(4) - x(5)))/((rob.R)/(rob.L));
    
%     D = [rob.vitesse, rob.angulation];
%     C = [(rob.R)/2 (rob.R)/2; (rob.R)/(rob.L) -(rob.R)/(rob.L)];
%     W = C\D;
    
    
    xdot(4) = ((u(1) - x(4)))/tau;
    xdot(5) = ((u(2) - x(5)))/tau;
end