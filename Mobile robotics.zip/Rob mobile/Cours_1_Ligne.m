figure(1)
clf
hold on
axis([-4 4 -5 5])
axis equal
dt=0.1;
Rob.nom='vico';
Rob.masse=6;
Rob.ptr=line([0 1],[-1 2],'color','r');
t=0;
while t<12
    set(Rob.ptr,'xdata',[0 1+t])
    %line ([0 1+t],[-1 2], 'color','r');
    drawnow
    t=t+dt;
end