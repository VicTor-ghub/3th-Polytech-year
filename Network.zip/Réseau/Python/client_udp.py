#Application communicante

from socket import *
import time

# Création de l’objet socket
s= socket(AF_INET, SOCK_DGRAM)

buffer= int(input("what do you want to do ? 1 : ON / 2 : OFF / 3 : state / 4: blink\n"))

if buffer == 1:
    s.sendto(bytes('B1on\n','utf-8'),('162.38.40.166',8888))

elif buffer == 2:
    s.sendto(bytes('B1off\n','utf-8'),('162.38.40.166',8888))

elif buffer == 3:
    s.sendto(bytes('B1?\n','utf-8'),('162.38.40.166',8888))

elif buffer == 4:
    i=0
    for i in range (0,10):
        s.sendto(bytes('B1on\n','utf-8'),('162.38.40.166',8888))
        time.sleep (1)
        s.sendto(bytes('B1off\n','utf-8'),('162.38.40.166',8888))
        time.sleep (1)

if buffer ==3:
    data,addr=s.recvfrom(1024) #ici reçoit ?
    data=data.decode('utf-8')
    print("recu :" ,data)


cmp= int(input("want to copy on TCP ? 1 : yes / 2 : no \n"))

if cmp == 1:
    
    s.sendto(bytes('B1?\n','utf-8'),('162.38.40.166',8888))
    data,addr=s.recvfrom(1024) #ici reçoit ?
    data=data.decode('utf-8')
    print("recu :" ,data)
    s.close()

    s=socket(AF_INET,SOCK_STREAM)
    s.connect(('162.38.40.166',8888))
    if data == 1:
        s.sendall(bytes('B1on\n','utf-8'))
    elif data ==0:
        s.sendall(bytes('B1off\n','utf-8'))

s.close()
