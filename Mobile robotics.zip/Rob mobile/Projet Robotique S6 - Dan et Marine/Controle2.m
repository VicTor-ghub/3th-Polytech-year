function [w_d,w_g]=Controle2(Etat,Cible,Capteurs) 

%%d�tection par capteur et initialisation des variables
    %conditions de d�tection:
        C1= Capteurs(1,1)<3; 
        C2= Capteurs(2,1)<3; 
    	C3= Capteurs(3,1)<3;
    %initialisation des variables:
        fin=0;
        Vecteur_cible=[Cible(1);Cible(2)];
        Vecteur_robot= [Etat(1);Etat(2)]; 
        Vecteur_final=Vecteur_cible-Vecteur_robot; 
    %calcul des coefficient: 
         if((Capteurs(1,1)<3)&&(Capteurs(1,1)>0))
            k1=Capteurs(1,1)/3;
        else
            k1=1;
        end       
         if((Capteurs(2,1)<3)&&(Capteurs(2,1)>0))
            k2=Capteurs(3,1)/3;
        else
            k2=1;
        end            
        if((Capteurs(3,1)<3)&&(Capteurs(3,1)>0))
            k3=Capteurs(3,1)/3;
        else
            k3=1;
        end       

%%controle robot (if/else et dans le dernier else la direction) 
if(C1 && C2 && C3)
      w_d = 7;
      w_g = -7;      
   else if (C2 && C3)
            w_d = 7*k3;
            w_g = 1/k2;
       else if(C1 && C2)
               w_d = 1/k2;
               w_g = 7*k1;
           else if(C1 && C3)
                   w_d = 7*k3;
                   w_g = 7*k1;
               else if(C3)
                      w_d = 7*k3;
                      w_g = 1/k2;
                   else if(C2)
                            w_d=7*k2;
                            w_g=7*k2;
                       else if(C1)
                                w_d = 1/k2;
                                w_g = 7*k1;
                           else  %si pas d'obstacle on dirige le robot: 
%%calcul de l'angle 
Angle = atan2(Vecteur_final(2),Vecteur_final(1));
Anglef = Etat(3) - Angle;

%%calcul de la distance 
d= sqrt((Vecteur_cible(1)-Vecteur_robot(1))^2+((Vecteur_cible(2)-Vecteur_robot(2))^2));

%calcul des commandes gr�ce aux angles orient�s: 
if (Anglef > 0)  
    Anglef2 = Anglef - 2*pi;  
else 
    Anglef2 = Anglef + 2*pi;
end 

if (abs(Anglef) < abs(Anglef2))
    Anglemin = Anglef;
else
    Anglemin = Anglef2;
end

if (Anglemin < 0)
    w_d = 3*(abs(Anglemin))+3;
    w_g = 0.5*(abs(Anglemin))+3;
else
    w_d = 0.5*(abs(Anglemin))+3;
    w_g = 3*(abs(Anglemin))+3;
end

if (d<0.1) %condition d'arr�t
    w_d=0.5;
    w_g=-0.5;     
    if (Etat(3)==Cible(3))
    w_d=0;
    w_g=0;
    end
end
                           end 
                       end
                   end
               end
           end
       end
   end



end 
