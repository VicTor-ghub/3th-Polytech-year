# AFFICHAGE simples 

using Plots
N=80;
x=0:2*pi/N:2*pi;
y=sin.(x);
y1=0.5*sin.(2*x);
figure1=plot(x,y,title="Titre",xlabel="axe x", ylabel="axe y",seriestype=:line, dpi=400, linewidth = 1.2,grid=true , gridlinewidth=1.0,xlim=(0,8),ylim=(-1,1) )


# AFFICHAGE Multiples (avec ! derrière le deuxieme plot)

figure1=plot(x,y,title="Titre",xlabel="axe x", ylabel="axe y",seriestype=:line, dpi=400, linewidth = 1.2,grid=true , gridlinewidth=1.0,xlim=(0,8),ylim=(-1,1) )
plot!(figure1,x,y1)

# AFFICHAGE subplot 

figure1=plot(x,y,title="Titre",xlabel="axe x", ylabel="axe y",seriestype=:line, linewidth = 1.2,grid=true , gridlinewidth=1.0,xlim=(0,8),ylim=(-1,1) )
figure2=plot(x,y1,title="Titre",xlabel="axe x", ylabel="axe y",seriestype=:line, linewidth = 1.2,grid=true , gridlinewidth=1.0,xlim=(0,8),ylim=(-1,1) )
plot(figure1,figure2,layout=(2,1),label=["f(t)" "g(t)"])

# SAUVEGARDER une figure dans un fichier

fig=plot(figure1,figure2,layout=(2,1),label=["f(t)" "g(t)"])
savefig(fig,"test.png")

# AFFICHER Plusieur figures

figure1=plot(x,y)
display(figure1)
figure2=plot(x,y1)
figure2=plot!(figure2,x,y1)
display(figure2)

# TRACER DES VECTEURS

u=(1,2);
v=(6,7);
quiver(x,y,quiver=(u,v))
