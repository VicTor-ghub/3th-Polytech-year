from socket import *
import time

s=socket(AF_INET,SOCK_STREAM)

#peut lancer le connect si le serveur a fait bind
s.connect(('162.38.40.166',8888))

buffer= int(input("what do you want to do ? 1 : ON / 2 : OFF / 3 : state / 4: blink\n"))

if buffer == 1:
    s.sendall(bytes('B1on\n','utf-8'))

elif buffer == 2:
    s.sendall(bytes('B1off\n','utf-8'))

elif buffer == 3:
    s.sendall(bytes('B1?\n','utf-8'))

elif buffer == 4:
    i=0
    for i in range (0,10):
        s.sendall(bytes('B1on\n','utf-8'))
        time.sleep (1)
        s.sendall(bytes('B1off\n','utf-8'))
        time.sleep (1)

if buffer == 3:
    data=s.recv(1024)
    data=data.decode('utf-8')

s.close()