function collision = collisionDetection(Etat,obstacles,Etat_old)

collision = 0;

%% Trajectoire du robot
A = Etat(1:2);
B = Etat_old(1:2);

%% Collision ?
for o = 1:size(obstacles,2)
    P = [obstacles(1,o); obstacles(2,o)];
    Q = [obstacles(3,o); obstacles(4,o)];
    
    M = [(B-A) (P-Q)];
    
    if(abs(det(M)) > 0.0001)
        st = M\(P-A);
        if(st(1) > 0 && st(1) < 1 && st(2) > 0 && st(2) < 1)
            collision = 1;
            return;
        end
    end
end