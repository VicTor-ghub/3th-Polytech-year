A0=10^(95/20);
f0=50*(10)^3;
w0=2*pi*f0;
A1= 1;
f1=300*(10)^6;
w1=2*pi*f1;

f_debut=1e0;
f_fin=1e6;
A=tf([A0],[1/w0 1]) ;
B=tf([A1],[1/w1 1]) ;
h1=bodeplot(A,B,{f_debut*2*pi,f_fin*2*pi}); %passe les frequences debut-fin

p = getoptions(h1);
p.YLimMode={'manual'};
p.YLim={[0 120];[-180 0]}; % gain de 0-120dB / phase de -180 a 0
p.Grid='on';
p.FreqUnits='Hz';

setoptions(h1,p); %applique les nouvelles options