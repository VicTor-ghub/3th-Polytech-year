%------------------------------CONTROLE------------------------------%

function commande=controle(Etat,Cible,Capteurs)

%-------------------------INITIALISATION GLOBALE-----------------------%

global R L dmax Nmin Thetamin wmax
% Thetamin = 0.03;
% Nmin=0.05;
% dmax= 3;
% wmax=10;
% R=0.05;%rayon des roues
% L=0.4; %1/2 Entreaxe

% Capteur=[dist1 angle1; dist2 angle2 ; dist3 angle3];
% Etat=[rob.X; rob.Y; rob.angle_dist_obs_rob; wd ; wg];
% Cible=[xd; yd; thetad];

%MATRICE DE PASSAGE
P = [R/2 R/2;R/L -R/L];

%CONDITIONS: VITESSE MAX
V_max= P*[wmax;wmax];
W_max=P*[wmax;-wmax];
Vmax=V_max(1);
Wmax=W_max(2);

V_W_maxD= P*[wmax/2;wmax]; % ANGLE MAX VERS DROITE
V_W_maxG= P*[wmax;wmax/2]; % ANGLE MAX VERS GAUCHE
rob.angle_dist_obs_rob=Etat(3);

%INCERTITUDES ANGLES
deltaP=(Thetamin+Cible(3))/Cible(3);
deltaN=(Cible(3)-Thetamin)/Cible(3);

%DEPART:   X / Y / angle_dist_obs_rob
start=[Etat(1); Etat(2); Etat(3)]; 
theta=mod(start(3),2*pi); % si tour complet 

%ARRIVEE
A=Cible;
norme1=sqrt((start(1)-A(1))^2+(start(2)-A(2))^2 );

%CAPTEURS
C1=Capteurs;
if C1(1,2)<0
    X=[C1(3,1) C1(3,2); C1(2,1) C1(2,2); C1(1,1) C1(1,2)];
else
    X=C1;
end
Dgauche=dmax*0.9;   %dist max de d�tection gauche
Dcentre=dmax;       %dist max de d�tection centre
Ddroite=dmax*0.9;   %dist max de d�tection droite

%INIT COMMANDE
w(1)=0;
w(2)=0;

%VITESSE EVITEMENT
if(X(1,1)<1.5 || X(2,1)<1.5 || X(3,1)<1.5)
    angle_dist_obs_rob= [0;0;0];
elseif(X(1,1)<dmax || X(2,1)<dmax || X(3,1)<dmax)
    angle_dist_obs_rob= [X(1,1)/dmax ; X(2,1)/dmax ; X(3,1)/dmax];
else
    angle_dist_obs_rob= [1 ; 1 ; 1];
end

%----------------POSITION ARRIVEE & ANGLE ARRIVEE-------------------%

if( A(1)<start(1))
    if( A(2)<start(2));
        C=2;
        angle3 = pi+ atan2(norm(A(2)-start(2)), norm(A(1)-start(1))); 
    else
        C=1;
        angle3 = pi- atan2(norm(A(2)-start(2)), norm(A(1)-start(1))); 
    end
else
    if( A(2)<start(2))
        C=4;
        angle3 = 2*pi- atan2(norm(A(2)-start(2)), norm(A(1)-start(1)));
    else
        C=3;
        angle3 = atan2(norm(A(2)-start(2)), norm(A(1)-start(1)));
    end
end

%CONDITIONS ARRIVEE
if(norme1 <= Nmin)
    XY=1; %vrai
else XY=0; %faux
end

%COMMANDE ARRET REDRESSEMENT
if(XY == 1) 
    if (theta < deltaN*Cible(3))
        V= 0;
        W= Wmax*0.7;
    elseif (theta > deltaP*Cible(3)) 
        V= 0;
        W= -Wmax*0.7;
    else
        V= 0;
        W= 0;
        disp ('tralala');
    end

%-------------------MODIFICATION TRAJECTOIRE----------------%

%PAS D'OBSTACLE
elseif(XY ==0)


    if( ( X(1,1)>=Dgauche &&  X(3,1)>=Ddroite && X(2,1)>=Dcentre )|| ...
        ( X(2,1)>= norme1 && X(1,1)>= norme1 && X(3,1)>= norme1 ))
    
        if( theta >= deltaN*(angle3) && theta <= deltaP*(angle3)) %dans axe
            V=Vmax*angle_dist_obs_rob(1,1); 
            W=0;
        elseif( (angle3==pi && theta==pi) || (angle3==0 && theta==0) )
                V= Vmax ;
                W= 0;
        elseif( (angle3==pi && theta==0) || (angle3==0 && theta==pi) )
                w(1)= 10; 
                w(2)= -5;
        elseif( (angle3==0 && theta>pi)|| (angle3 ==pi && theta<pi ))
                V= V_W_maxG(1); 
                W= V_W_maxG(2);
        elseif( (angle3==0 && theta<pi)|| (angle3 ==pi && theta>pi ))
                V= V_W_maxD(1); 
                W= V_W_maxD(2);
        elseif( (theta==0 && angle3>pi)|| (theta ==pi && angle3<pi ))
                V= V_W_maxG(1); 
                W= V_W_maxG(2);
        elseif( (theta==0 && angle3<pi)|| (theta ==pi && angle3>pi ))
                V= V_W_maxD(1); 
                W= V_W_maxD(2);
                
        elseif(  angle3 < pi ) %plus haut que l'arriv�e
            if( theta <0.8*(pi+angle3) && theta > 1.2*angle3 )
                V= V_W_maxD(1); 
                W= V_W_maxD(2);
            elseif(  theta >1.2*(pi+angle3) || theta < 0.8*angle3)
                V= V_W_maxG(1); 
                W= V_W_maxG(2);
            elseif( theta <deltaN*(pi+angle3) && theta > deltaP*angle3 )
                V= V_W_maxD(1); 
                W= V_W_maxD(2);
            elseif(  theta >deltaP*(pi+angle3) || theta < deltaN*angle3)
                V= V_W_maxG(1); 
                W= V_W_maxG(2);
            else %DEBUG
                V=Vmax*angle_dist_obs_rob(1,1);
                W=0;
            end
        elseif(  angle3 > pi ) %plus bas que l'arriv�e
            if( theta < 0.8*(angle3-pi) || theta > 1.2*(angle3) )
                V= V_W_maxD(1); 
                W= V_W_maxD(2);
            elseif(  theta > 1.2*(angle3-pi)&& theta< 0.8*angle3)
                V= V_W_maxG(1); 
                W= V_W_maxG(2);
            elseif( theta < deltaN*(angle3-pi) || theta > deltaP*(angle3) )
                V= V_W_maxD(1); 
                W= V_W_maxD(2);
            elseif(  theta > deltaP*(angle3-pi)&& theta< deltaN*angle3)
                V= V_W_maxG(1); 
                W= V_W_maxG(2);
            else %DEBUG
                V=Vmax*angle_dist_obs_rob(1,1);
                W=0;
            end
        else V=Vmax;W=0; 
        end
    
%DETECTION D'UN OBSTACLE

    elseif(X(2,1)<0.5*dmax || X(1,1)<0.5*dmax || X(3,1)<0.5*dmax )
        V=0;
        if(X(1,1)<0.5*dmax && X(3,1)<0.5*dmax)
            W= -Wmax*0.8;
        elseif(X(3,1)<0.5*dmax)
            W=  Wmax*0.8;
        elseif(X(1,1)<0.5*dmax)
            W= -Wmax*0.8;
        elseif( X(2,1)<0.5*dmax)
            V= -1;
            W= -Wmax;
        end

%DOUBLE DETECTION

    elseif(X(2,1)<Dcentre)
        if (X(1,1)<Dgauche)
            if (X(3,1)<Ddroite)
                V= -Vmax*4;
                W= Wmax*0.8;
            else
                V= V_W_maxD(1)*0.2;
                W= V_W_maxD(2)*1;            
            end
  
        elseif (X(1,1)>=Dgauche)
            if (X(3,1)<Ddroite)
                V= V_W_maxG(1)*0.2;
                W= V_W_maxG(2)*1;  
            else
                if(X(3,1)<X(1,1))
                    V= V_W_maxD(1);
                    W= V_W_maxD(2);     
                else
                    V= V_W_maxG(1);
                    W= V_W_maxG(2);  
                end
            end
        end

%TRIPLE DETECTION 

    elseif (X(2,1)>=Dcentre)
        if (X(1,1)<Dgauche)
            if (X(3,1)<Ddroite) 
                    V= Vmax*0.8;
                    W= 0;   
            else
                V= V_W_maxD(1)*0.2;
                W= V_W_maxD(2)*1;            
            end
            
        elseif (X(1,1)>=Dgauche)
            
            %DETECTION DROITE ET GAUCHE
            if (X(3,1)<Ddroite)
                     if(       ((C==2 || C==4 )&& (rob.angle_dist_obs_rob>=pi/3 || rob.angle_dist_obs_rob < 2*pi/3 )) ...
                            || ((C==2 || C==1 )&& (rob.angle_dist_obs_rob<pi/3 || rob.angle_dist_obs_rob>=0 ))...
                            || ((C==3 || C==1 )&& (rob.angle_dist_obs_rob>3*pi/2 || rob.angle_dist_obs_rob<=2*pi )) ...
                            || ((C==3 || C==4 )&& (rob.angle_dist_obs_rob>pi || rob.angle_dist_obs_rob<=3*pi/2 ))  )

                        V=Vmax*angle_dist_obs_rob(3,1);
                        W=Wmax*0.8;
                     else
                        V= V_W_maxG(1)*0.2;
                        W= V_W_maxG(2)*1; 
                     end       
            end
        end
    
    end
else disp('erreur') %DEBUG
    W= 0;
    V= 0;            
end

%ASSERVISSEMENT DE VITESSE MAX 

if(w(1)==0 && w(2)==0)
    w= P\[V ;W];
else w=w';
end

%si d�passement de vitesse
if(abs(w(1))>wmax || abs(w(2))>wmax) 
    if(abs(w(1))>=abs(w(2)))
          K = wmax/w(1); 
          w(1) = wmax; 
          w(2) = K*w(2); 
    elseif(w(1)<=w(2))
          K = wmax/w(2);
          w(2) = wmax;
          w(1) = K*w(1);
    end
end

%---------------------------ARRET A L'ARRIVEE----------------------%

e = Etat(3)-Cible(3);
e = angle( cos(e) + 1i * sin(e) );
if norm(Etat(1:2)-Cible(1:2))<Nmin
    w(1)= abs(e/pi)*w(1);
    w(2)= abs(e/pi)*w(2);
    if abs(e)<Thetamin
        w(1)= 0;
        w(2)= 0;
    end
end

commande=w;

%END CONTROLE

end