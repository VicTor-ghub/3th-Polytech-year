function obstacle(a)

for i=1:1:size(a)
        obst1=[a(i,1) a(i,2)];
        obst2=[a(i,3) a(i,4)];
        P=[obst1;obst2];
        fig_ar1 = [1, 2];
        patch('vertices',P,'faces',fig_ar1,'edgecolor','b', 'LineWidth',1);
    end
end
