P= ginput(1);
R= ginput(1);
A=ginput(1);
B=ginput(1);

alpha=0;
smin=s(1);

M=[P-R A-B];
if detM> 0.0001
    alpha= inv(M)*(A-R)
    for i=1:1:3
        if alpha(1)<=smin && s(i)>=0
            if t(i)<=1 && s(i)>=0  %une intersection
            end
        end
        if smin > s(i)
            smin=s(i);
        end
    end
end
