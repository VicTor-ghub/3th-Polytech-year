%Mise en place du rep�re
figure(1)
clf
hold on
axis([-4 4 -5 5])
axis equal
a=[1 0];
b=[0 -0.5];
c=[0 0.5];
sommets=[a;b;c]
faces=[1 2 3];
%ptrTriangle=patch('vertices', sommets, 'faces', faces, 'facecolor', 'r');

%Calcul


% R�cup�ration de R et de M
[A,B] = ginput(1);% R�cup�ration de R
[J,K] = ginput(1);% R�cup de M
V = [J-A K-B];% Calcule du vecteur RM
teta = atan2(V(2), V(1))% Calcule de l'angle par rapport � l'axe des abscisses

matrice=[cos(teta) -sin(teta) A;sin(teta) cos(teta) B; 0 0 1]% Matrice du cours
% A et B sont les coordonn�es du point R -> l'endroit o� doit �tre c�l� le
% nouveau triangle
aprime = matrice*[a(1);a(2);1]% Nouvelle coordon�es du point a
bprime = matrice*[b(1);b(2);1]% Nouvelle coordon�es du point b
cprime = matrice*[c(1);c(2);1]% Nouvelle coordon�es du point c
sommets2=[[aprime(1) aprime(2)]; [bprime(1) bprime(2)] ;[cprime(1) cprime(2)]] % Nouveau triangle

ptrTriangle=patch('vertices', sommets2, 'faces', faces, 'facecolor', 'b');