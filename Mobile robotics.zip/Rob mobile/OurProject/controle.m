function commande=controle(Etat,Cible,Capteurs)

global R L dmax Nmin Thetamin wmax
% Capteur=[dist1 angle1; dist2 angle2 ; dist3 angle3];
% Etat=[rob.X; rob.Y; rob.theta; wd ; wg];
% Cible=[xd; yd; thetad];

%matrice de passage (V;w)=P*(wd;wg)
P = [R/2 R/2;R/L -R/L];

%calculs des vitesses extr�mes
V_max= P*[wmax;wmax];
W_max=P*[wmax;-wmax];
Vmax=V_max(1);
Wmax=W_max(2)*0.8;

%calculs des vitesses lin�aire et angulaire max
V_W_maxD= P*[wmax/2;wmax]*0.8; % max vers la droite
V_W_maxG= P*[wmax;wmax/2]*0.8; % max vers la gauche
rob.theta=Etat(3);

%incertitudes d'angles
IncP=(Thetamin+Cible(3))/Cible(3);
IncN=(Cible(3)-Thetamin)/Cible(3);

% position de D�part (De):   X / Y / theta
De=[Etat(1); Etat(2); Etat(3)]; 
y=mod(De(3),2*pi); % theta modulo 2pi si il fait plus d'un tour

%valeurs des capteurs
X1=Capteurs;
if X1(1,2)<0
    X=[X1(3,1) X1(3,2); X1(2,1) X1(2,2); X1(1,1) X1(1,2)];
else
    X=X1;
end
Ddroite=dmax*0.9;   %distance de d�tection max doite
Dgauche=dmax*0.9;   %distance de d�tection max gauche
Dcentre=dmax;       %distance de d�tection max centre

%points d'arrivee
A=Cible;
norme1=sqrt((De(1)-A(1))^2+(De(2)-A(2))^2 );

%initisalisation des commandes
u(1)=0;
u(2)=0;

%vitesse calcul�e pour evitements
if(X(1,1)<1.5 || X(2,1)<1.5 || X(3,1)<1.5)
    taux_distance_OBS_ROBOT= [0;0;0];
elseif(X(1,1)<dmax || X(2,1)<dmax || X(3,1)<dmax)
    taux_distance_OBS_ROBOT= [X(1,1)/dmax ; X(2,1)/dmax ; X(3,1)/dmax];
else
    taux_distance_OBS_ROBOT= [1 ; 1 ; 1];
end

%        y=0
%    1   |    3
% _______|________ x=0  Cadrans
%        |
%    2   |    4

%-------------------------------------------------------------------------
%---------------- POSITION de l'arrivee/point en d�placmt ----------------
%-------------------------------------------------------------------------
%----------------CALCUL DE L'ANGLE ENTRE LES 3PTS (De,A,De)---------------
%-------------------------------------------------------------------------

if( A(1)<De(1))
    if( A(2)<De(2));
        C=2;
        angle3 = pi+ atan2(norm(A(2)-De(2)), norm(A(1)-De(1))); 
    else
        C=1;
        angle3 = pi- atan2(norm(A(2)-De(2)), norm(A(1)-De(1))); 
    end
else
    if( A(2)<De(2))
        C=4;
        angle3 = 2*pi- atan2(norm(A(2)-De(2)), norm(A(1)-De(1)));
    else
        C=3;
        angle3 = atan2(norm(A(2)-De(2)), norm(A(1)-De(1)));
    end
end

%-------------------------------------------------------------------------
%------------------- CONDITIONS d'arriv�e � destination ------------------
%-------------------------------------------------------------------------

if(norme1 <=Nmin)
    XY=1; %vrai
else XY=0; %faux
end

%-------------------------------------------------------------------------
%---------------------- CONDITIONS DE trajectoire ------------------------
%-------------------------------------------------------------------------

%-------------------------------------------------------------------------
%----------------------V�rification position finale ----------------------
%-------------------------------------------------------------------------

if(XY == 1) 
    if(y >= IncN*Cible(3) && y <= IncP*Cible(3))
        V= 0;
        W= 0;
    elseif (y < 0.8*Cible(3))
        V= 0;
        W= Wmax;
    elseif (y > 1.2*Cible(3)) 
        V= 0;
        W= -Wmax;
    elseif (y < IncN*Cible(3))
        V= 0;
        W= Wmax*0.3;
    elseif (y > IncP*Cible(3)) 
        V= 0;
        W= -Wmax*0.3;
    end

%-------------------------------------------------------------------------
%---------------Choix Obstalce/Trajectoire suivant Capteurs---------------
%-------------------------------------------------------------------------

elseif(XY ==0)
%-------------------------------------------------------------------------
%--------------------------- 1.AUCUN OBSTACLE ----------------------------
%-------------------------------------------------------------------------

    if( ( X(1,1)>=Dgauche &&  X(3,1)>=Ddroite && X(2,1)>=Dcentre )|| ...
        ( X(2,1)>= norme1 && X(1,1)>= norme1 && X(3,1)>= norme1 ))
    
        if( y >= IncN*(angle3) && y <= IncP*(angle3)) %si align� 
            V=Vmax*taux_distance_OBS_ROBOT(1,1);
            W=0;
        elseif( (angle3==pi && y==pi) || (angle3==0 && y==0) )
                V= Vmax ;
                W= 0;
        elseif( (angle3==pi && y==0) || (angle3==0 && y==pi) )
                u(1)= 10; 
                u(2)= -5;
        elseif( (angle3==0 && y>pi)|| (angle3 ==pi && y<pi ))
                V= V_W_maxG(1); 
                W= V_W_maxG(2);
        elseif( (angle3==0 && y<pi)|| (angle3 ==pi && y>pi ))
                V= V_W_maxD(1); 
                W= V_W_maxD(2);
        elseif( (y==0 && angle3>pi)|| (y ==pi && angle3<pi ))
                V= V_W_maxG(1); 
                W= V_W_maxG(2);
        elseif( (y==0 && angle3<pi)|| (y ==pi && angle3>pi ))
                V= V_W_maxD(1); 
                W= V_W_maxD(2);
                
        elseif(  angle3 < pi ) %si pt actuel plus haut que l'arriv�e
            if( y <0.8*(pi+angle3) && y > 1.2*angle3 )%si rob.theta plus grand que l'angle
                V= V_W_maxD(1); 
                W= V_W_maxD(2);
            elseif(  y >1.2*(pi+angle3) || y < 0.8*angle3)%si rob.theta plus grand que l'angle
                V= V_W_maxG(1); 
                W= V_W_maxG(2);
            elseif( y <IncN*(pi+angle3) && y > IncP*angle3 )
                V= V_W_maxD(1)*0.5; 
                W= V_W_maxD(2)*0.5;
            elseif(  y >IncP*(pi+angle3) || y < IncN*angle3)
                V= V_W_maxG(1)*0.5; 
                W= V_W_maxG(2)*0.5;
            else %condition extr�me
                V=Vmax*taux_distance_OBS_ROBOT(1,1);
                W=0;
            end
        elseif(  angle3>pi )
            if( y < 0.8*(angle3-pi) || y > 1.2*(angle3) )
               V= V_W_maxD(1); 
                W= V_W_maxD(2);
            elseif(  y > 1.2*(angle3-pi)&& y< 0.8*angle3)
                V= V_W_maxG(1); 
                W= V_W_maxG(2);
            elseif( y < IncN*(angle3-pi) || y > IncP*(angle3) )
                V= V_W_maxD(1)*0.5; 
                W= V_W_maxD(2)*0.5;
            elseif(  y > IncP*(angle3-pi)&& y< IncN*angle3)
                V= V_W_maxG(1)*0.5; 
                W= V_W_maxG(2)*0.5;
            else %condition extr�me
                V=Vmax*taux_distance_OBS_ROBOT(1,1);
                W=0;
            end
        else V=Vmax;W=0; %condition extr�me
        end
    
%-------------------------------------------------------------------------
%-------------------- Si on d�tecte un/des obstacles ---------------------
%-------------------------------------------------------------------------
    elseif(X(2,1)<0.5*dmax || X(1,1)<0.5*dmax || X(3,1)<0.5*dmax )
        V=0;
        if(X(1,1)<0.5*dmax && X(3,1)<0.5*dmax)
            W= -Wmax*0.8;
        elseif(X(3,1)<0.5*dmax)
            W=  Wmax*0.8;
        elseif(X(1,1)<0.5*dmax)
            W= -Wmax*0.8;
        elseif( X(2,1)<0.5*dmax)
            V= -1;
            W= -Wmax;
        end
    %-------- 03 : D�tection Vert < Dcentre---%
    elseif(X(2,1)<Dcentre)
        %-------- 03.1 : D�tection Rouge < Dgauche---%
        if (X(1,1)<Dgauche)
            %-------- 03.1.1 : D�tection Bleu < Ddroite---%
            if (X(3,1)<Ddroite)
                V= -Vmax*0.5;
                W= Wmax*0.8;
            %-------- 03.1.2 : D�tection Bleu >= Ddroite --%
            else
                V= V_W_maxD(1)*0.2;
                W= V_W_maxD(2)*1.5;            
            end
        %-------- 03.2 : D�tection Rouge >= Dgauche---%    
        elseif (X(1,1)>=Dgauche)
           
            %-------- 03.2.1 : D�tection Bleu < Ddroite --%
            if (X(3,1)<Ddroite)
                V= V_W_maxG(1)*0.2;
                W= V_W_maxG(2)*1.5;  
            %-------- 03.2.2 : D�tection Bleu >= Ddroite --%
            else
                if(X(3,1)<X(1,1))
                    V= V_W_maxD(1);
                    W= V_W_maxD(2);     
                else
                    V= V_W_maxG(1);
                    W= V_W_maxG(2);  
                end
            end
        end

    %-------- 04 : D�tection Vert >= Dcentre--%    
    elseif (X(2,1)>=Dcentre)
        %-------- 04.1 : D�tection Rouge < Dgauche---%
        if (X(1,1)<Dgauche)
            %-------- 04.1.1 : D�tection Bleu entre <Ddroite---%
            if (X(3,1)<Ddroite) 
                    V= Vmax*0.8;
                    W= 0;   
               
            %-------- 04.1.2 : D�tection Bleu entre >=Ddroite---%   
            else
                V= V_W_maxD(1)*0.2;
                W= V_W_maxD(2)*1.5;            
            
            end
        %-------- 04.2 : D�tection Rouge >= Dgauche---%    
        elseif (X(1,1)>=Dgauche)
            %-------- 04.2.1 : D�tection Bleu entre <Ddroite---%
            if (X(3,1)<Ddroite)
                     if(       ((C==2 || C==4 )&& (rob.theta>=pi/3 || rob.theta < 2*pi/3 )) ...
                            || ((C==2 || C==1 )&& (rob.theta<pi/3 || rob.theta>=0 ))...
                            || ((C==3 || C==1 )&& (rob.theta>3*pi/2 || rob.theta<=2*pi )) ...
                            || ((C==3 || C==4 )&& (rob.theta>pi || rob.theta<=3*pi/2 ))  )

                        V=Vmax*taux_distance_OBS_ROBOT(3,1);
                        W=Wmax*0.8;
                     else
                        V= V_W_maxG(1)*0.2;
                        W= V_W_maxG(2)*1.5; 
                     end       
            end
        end
    
    end
else disp('erreur') %cas extr�me
    W= 0;
    V= 0;            
end

%-------------------------------------------------------------------------
%--------------- V�rification de la commande de vitesse max---------------
%-------------------------------------------------------------------------

if(u(1)==0 && u(2)==0)
    u= P\[V ;W];
else u=u';
end

%si on d�passe la limite de vitesse
if(u(1)>wmax || u(2)>wmax) 
    if(u(1)>=u(2))
          K = wmax/u(1); 
          u(1) = wmax; 
          u(2) = K*u(2); 
    elseif(u(1)<=u(2))
          K = wmax/u(2);
          u(2) = wmax;
          u(1) = K*u(1);
    end
    disp('condition')
end

%-------------------------------------------------------------------------
%------------- condition d'arriv�e atteinte � Thetamin pr�s --------------
%-------------------------------------------------------------------------

if(y >= IncN*Cible(3) && y <= IncP*Cible(3) && norme1< Nmin)
        u(1)= 0;
        u(2)= 0;
end

%-------------------------------------------------------------------------
%--------------------------------- FIN -----------------------------------
%-------------------------------------------------------------------------

commande=u;

end

