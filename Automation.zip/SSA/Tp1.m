w0=7053;
z=0.25;
H0=tf([-1],[1/w0^2 2*z/w0 1]);
%step((-3.38*H0)-3.38);

w01=314159;
w02=1.88e9;
w04=3e9;



A0=10^(95/20);
f0=50e3;
w0=2*pi*f0;
H1=tf([A0],[1/w01 1]);
H2=tf([1],[1/w02 1]);
H4=tf([1],[1/w04 1]);
H3=H1*H2*H4;
f_debut=1e3;
f_fin=1e9;

h1=bodeplot(H3,{f_debut*2*pi,f_fin*2*pi}); %passe les frequences debut-fin

p = getoptions(h1);
p.YLimMode={'manual'};
p.YLim={[0 120];[-180 0]}; % gain de 0-120dB / phase de -180 a 0
p.Grid='on';
p.FreqUnits='Hz';

setoptions(h1,p); %applique les nouvelles options