figure(1)
clf
hold on
axis([-4 4 -5 5])
axis equal
a=[1 0];
b=[0 -0.5];
c=[0 0.5];
sommets=[a;b;c]
faces=[1 2 3];
Rob.nom='vico';
Rob.masse=6;
Rob.ptr=patch('vertices', sommets, 'faces', faces, 'facecolor', 'r');
dt=0.1;
t=0;
while t<12
    aprime=[a(1)+t a(2)+t];
    bprime=[b(1)+t b(2)+t];
    cprime=[c(1)+t c(2)+t];
    sommetsprime=[aprime;bprime;cprime]
    set(Rob.ptr,'vertices',sommetsprime)
    drawnow
    t=t+dt;
end

%function edot= toto(e,u,p);
%[T,X]=ode45(a(t,a)modeleRob(t,sommets,parametres),[0 dt],etat) 