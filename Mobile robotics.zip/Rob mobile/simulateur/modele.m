function edot = modele(Etat,commande,rob)
edot = 0*Etat;
tau = 0.1;  %constante (moteurs)
edot(1) = (rob.R/2)*(Etat(4)+Etat(5))*cos(Etat(3));
edot(2) = (rob.R/2)*(Etat(4)+Etat(5))*sin(Etat(3));
edot(3) = (rob.R/(2*rob.L))*(Etat(4)-Etat(5));
edot(4) = (-1/tau)*Etat(4)+(1/tau)*commande(1);
edot(5) = (-1/tau)*Etat(5)+(1/tau)*commande(2);
end

%etat(1)<=>x
%etat(2)<=>y
%etat(3)<=>theta
%etat(4)<=>wD
%etat(5)<=>wG