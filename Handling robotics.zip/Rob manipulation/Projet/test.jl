# Modèle Cinématique Inverse (MCI)

function MCI(xr_dot,yr_dot,theta1, theta2)
    J=MCD(theta1,theta2)

    if det(J)<0.001
        J_inv=inv(J)
        #Vitesse carthésienne
        xr_dot=1;
        yr_dot=0;
        #Récupération vitesse angulaire
        theta_dot=[];
        theta_dot[1]=J_inv*xr_dot;
        theta_dot[2]=J_inv*yr_dot;
        return theta_dot
    
    elseif println("Matrice J non inversible ")
    end    
end

MCI()