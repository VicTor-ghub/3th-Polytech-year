function Capteurs_Rob1=detectionRob(Rob1, Rob2, Capteurs)

dmax = 3;

Capteurs_Rob1 = Capteurs;

a = Rob2(1:2) + 0.8*[cos(Rob2(3));sin(Rob2(3))];
b = Rob2(1:2) + 0.4*[cos(Rob2(3)+pi/2);sin(Rob2(3)+pi/2)];
c = Rob2(1:2) + 0.4*[cos(Rob2(3)-pi/2);sin(Rob2(3)-pi/2)];

arretes = [[a(1);a(2);b(1);b(2)] ,...
           [b(1);b(2);c(1);c(2)] ,...
           [c(1);c(2);a(1);a(2)] ];

for c = 1:3
    
    A = Rob1(1:2);
    B = [Rob1(1)+dmax*cos(Rob1(3) + Capteurs_Rob1(c,2)) ;...
         Rob1(2)+dmax*sin(Rob1(3) + Capteurs_Rob1(c,2))];
    
    d = Capteurs_Rob1(c,1);
    for o=1:size(arretes,2)
        
        P = [arretes(1,o);arretes(2,o)];
        Q = [arretes(3,o);arretes(4,o)];
        
        H = [(B-A) (P-Q)];
        
        if(abs(det(H))>0.0001)
            st = H\(P-A);
            if(st(1) > 0 && st(1) < 1 && st(2) > 0 && st(2) < 1)
                dx = B(1)-A(1);
                dy = B(2)-A(2);
                distance = st(1) * sqrt(dx^2 + dy^2);
                if(distance <d)
                    d = distance;
                end
            end
        end
    end
    
    Capteurs_Rob1(c,1) = d;
end
%% DEBUG
% for c=1:3
%     if ( (Capteurs_Rob1(c,1) < Capteurs(c,1)) && (Capteurs_Rob1(c,1) > 0))
%         plot( Rob1(1)+Capteurs_Rob1(c,1)*cos(Rob1(3)+Capteurs_Rob1(c,2)),...
%             Rob1(2)+Capteurs_Rob1(c,1)*sin(Rob1(3)+Capteurs_Rob1(c,2)),'r.');
%     end
% end
end