function u = controle(Etat, Cible, Capteurs)
    dmax = 3;   %On fait passer le dmax dans controle.m
    fin = 0;    %Variable d�terminant si on est sur la cible
    C = [0.05/2 0.05/2; 0.05/0.8 -0.05/0.8];    % Matrice de conversion de vitesse-vitesse de rotation ==> roue droite roue gauche
    
    if(fin == 0) %tant que le robot n'est pas arr�t�
    if((Capteurs(1,1) <= dmax)&&(Capteurs(1,1)>= 0)) %Cas o� le capteur � -pi/6 d�tecte un obstacle
        donnetout = 1;
        %disp(donnetout);
    else
        if((Capteurs(2,1) <= dmax)&&(Capteurs(2,1)>= 0))%Cas o� le capteur � 0 d�tecte un obstacle
            donnetout = 2;
            %disp(donnetout);
        else
            if((Capteurs(3,1) <= dmax)&&(Capteurs(3,1)>= 0))%Cas o� le capteur � pi/6 d�tecte un obstacle
                donnetout = 3;
                %disp(donnetout);
            else %Cas o� aucun des capteurs ne d�tecte d'obstacles
                donnetout = 0;
                %disp(donnetout);
            end
        end
    end
    
       switch(donnetout) %On fait tourner le robot suivant l'�tat des capteurs
           case 1
                 v(1) = 0.7; %vitesse du robot
                 v(2) = 0.03; %vitesse de rotation du robot
           case 2
                 v(1) = 0.7;
                 v(2) = 0.03;
           case 3
                 v(1) = 0.7;
                 v(2) = -0.03;
           otherwise
                 v(1) = 0.7;
                 v(2) = 0;
       end
       u = C\(v'); %On convertit ces valeurs en vitesse de rotation de chaque roue du robot
       if((abs(Cible(1)-Etat(1))<=4)||((abs(Cible(2)-Etat(2)))<=4)) %Si la cible est dans un certain rayon autour du robot
            Etat(3) = Etat(3) - atan(abs(Cible(2)-Etat(2))/abs(Cible(1)-Etat(1))); %Angle auquel se trouve la cible par rapport au robot
            
            if (Etat(3) > 0)  %On fait en sorte que cet angle soit compris dans ]-pi;pi]
                alpha = Etat(3) - 2*pi; %On dit que alpha est "l'angle arrang�" pour mieux comprendre la suite du code
            else 
                alpha = Etat(3) + 2*pi;
            end 

            if (abs(Etat(3)) < abs(alpha)) %si l'angle calcul� est inf�rieur � l'angle arrang�
                alphavrai = Etat(3); %On prend l'angle le plus petit qui est le bon
            else
                alphavrai = alpha;
            end

            if (alphavrai < 0) %On fait tourner les roues (plus facile dans ce cas-l� que d'utilise la vitesse et la vitesse de rotation
                u = [3*(abs(alphavrai))+3;0.5*(abs(alphavrai))+3]; %La vitesse de rotation des roues d�pend de si le robot doit tourner � gauche ou � droite d'o� la condition avec deux cas
            else
                u = [0.5*(abs(alphavrai))+3;3*(abs(alphavrai))+3];
            end
            if((abs((Cible(1)-Etat(1)))<=0.1)&&((abs(Cible(2)-Etat(2)))<=0.1)) %Si le robot est tr�s proche de la cible
                u(1) = 0; %arr�t du robot
                u(2) = 0;
                fin = 1;
            end
       end
    end 
end
