%-------------------------MAIN-------------------------%

%Initialisation de l'environnement
figure(1)
clf
hold on
%Intialisation du rep�re carth�sien
axis([-20 20 -20 20]) 
axis equal

%Initialisation du robot
global R L dmax Nmin Thetamin wmax;
Thetamin = 0.02;
Nmin=0.5;
dmax= 3;
wmax=10;
R=0.05;%rayon des roues
L=0.4; %1/2 Entreaxe
Longueur=0.8; %longueur du robot

%Position du robot
rob.X=16;
rob.Y=11;
rob.theta=pi/2;

rob.nom='Malloc Zebiii';
rob.H= Longueur;
rob.R= R;
rob.L= L;

%Cr�ation du robot
fig_pt = [0 -Longueur/2; 0 Longueur/2; Longueur 0];
fig_ar = [1 2 ;2 3;3 1];
fig = patch('vertices',fig_pt,'faces',fig_ar,'edgecolor','m');
%Cr�ation de la cible
xd= 0;
yd= 0;
thetad=3*pi/2;

%Initialisation commande 
wdbarre=0;
wgbarre=0;
commande=[wdbarre; wgbarre]; %[wd;wg]
%Initialisation temps
Tmax=1000;
dt=0.1;

%Intialisation des capteurs*
Milieu=[0 0];

angle1=pi/6;
dist1=dmax;
Pgauche=[dist1*cos(angle1) dist1*sin(angle1)];
obst1=[1 2];
figb1 = patch('vertices',[Milieu;Pgauche],'faces',obst1,'edgecolor','m');

angle2=0;
dist2=dmax;
Pcentre=[dist2*cos(angle2) dist2*sin(angle2)];
figb2 = patch('vertices',[Milieu;Pcentre],'faces',obst1,'edgecolor','m');

angle3=-pi/6;
dist3=dmax;
Pdroite=[dist3*cos(angle3) dist3*sin(angle3)];
figb3 = patch('vertices',[Milieu;Pdroite],'faces',obst1,'edgecolor','m');

%Initialisation des param�tres
Capteurs=[dist1 angle1; dist2 angle2 ; dist3 angle3];
Etat=[rob.X; rob.Y; rob.theta; commande(1,1) ; commande(2,1)];
Cible=[xd; yd; thetad];

%Affichage d�part et arriv�e
scatter(xd,yd)
scatter(rob.X, rob.Y)

%Affichage des obstacles
obstacle(coor_obst())

for t=0 : dt : Tmax

drawnow
  
rob.X=Etat(1);
rob.Y=Etat(2);
rob.theta=Etat(3);

% M et Mprime : matrices de rotation
% T et Tprime : vecteurs de translation

M=[cos(rob.theta) -sin(rob.theta) ; sin(rob.theta) cos(rob.theta)];
T=[rob.X rob.Y;rob.X rob.Y;rob.X rob.Y];
F=T+(M*fig_pt')';

Mprime=[cos(rob.theta) -sin(rob.theta) ; sin(rob.theta) cos(rob.theta)];
Tprime=[rob.X rob.Y;rob.X rob.Y];
F2=Tprime+(Mprime*[Milieu;Pcentre]')'; 
F3=Tprime+(Mprime*[Milieu;Pdroite]')';
F1=Tprime+(Mprime*[Milieu;Pgauche]')';

%-------------Trajectoire/Intersection/Capteurs-----------------%

%Nouvelles coordonn�es du robot et des capteurs
set(fig,'vertices',F);
set(figb1,'vertices',F1);
set(figb2,'vertices',F2);
set(figb3,'vertices',F3);

%Nouvelles coordonn�es des capteurs
Pdroitebis=[F3(2, 1) F3(2,2)];  %point du laser centre
Pcentrebis=[F2(2, 1) F2(2,2)];  %point du laser gauche
Pgauchebis=[F1(2, 1) F1(2,2)];  %point du laser droite

Rbis=[F3(1,1),F3(1,2)];    %point central de l'entraxe

%coordonn�es d'obstacles (� revoir) 
obs=coor_obst();

%Intersection = d�tetection des obstacles

%X est le vecteurs ayant les valeurs d'intersection S et Gamma minimales 
X=detection(obs,13, Pgauchebis, Pcentrebis, Pdroitebis,  Rbis);

%Distance d�tect�e par les capteurs (angles fixes)
Capteurs =[ X(1,1)*dist1 angle1; X(2,1)*dist2 angle2; X(3,1)*dist3 angle3];

%Trajectoire
commande=controle(Etat,Cible,Capteurs);

%END: Condition d'arriv�e � destination
if(commande==[0;0])
    disp('Le robot est arriv� � destination');
    
end

%Int�gration des vitesses pour r�cup�ration de la position avec T=t+dt
    [T,X]= ode45(@(t,Etat)modeleRobot(Etat,commande,rob),[0 dt],Etat);
    Etat=X(length(X),:)';

end